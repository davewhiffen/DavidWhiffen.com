// ==UserScript==
// @name         Indeed UI Improvements
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.indeed.ca/*
// @grant        none
// ==/UserScript==

// Applied
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Applied/g,'<img src="http://www.goclutch.com/indeed/UI/CHECK.jpg" height="15"> Applied');})();

// Toronto
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toronto, ON/g,'<img src="http://www.goclutch.com/indeed/UI/TOR.png" height="15"> Toronto, ON');})();








