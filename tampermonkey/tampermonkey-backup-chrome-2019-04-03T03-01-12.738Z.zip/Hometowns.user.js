// ==UserScript==
// @name         Hometowns
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==


// Toronto
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/TORONTO.png" height="15"> Toronto, ONT');})();

// Mississauga
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Mississauga, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/MISS.png" height="15"> Mississauga, ONT');})();

// London
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/London, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/LONDON.png" height="15"> London, ONT');})();

// Hamilton
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Hamilton, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/HAMILTON.png" height="15"> Hamilton, ONT');})();

// Oakville
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Oakville, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/OAKVILLE.png" height="15"> Oakville, ONT');})();

// Thunder Bay
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Thunder Bay, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/THUNDER-BAY.png" height="15"> Thunder Bay, ONT');})();


// Oshawa
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Oshawa, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/OSHAWA.png" height="15"> Oshawa, ONT');})();



// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Georgetown, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/GEORGETOWN.png" height="15"> Georgetown, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Bracebridge, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/MUSKOKA.png" height="15"> Bracebridge, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Scarborough, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/SCARBOROUGH.png" height="15"> Scarborough, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Richmond Hill, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/RICHMOND-HILL.png" height="15"> Richmond Hill, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Markham, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/MARKHAM.png" height="15"> Markham, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Brampton, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/BRAMPTON.png" height="15"> Brampton, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Vaughan, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/VAUGHAN.png" height="15"> Vaughan, ONT');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/###, ONT/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/city/##.png" height="15"> ##, ONT');})();







