// ==UserScript==
// @name         QMJHL
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Acadie-Bathurst Titan/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/ACA.png" height="15"> Acadie-Bathurst Titan');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Baie-Comeau Drakkar/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/BAI.png" height="15"> Baie-Comeau Drakkar');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Blainville-Boisbriand Armada/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/BLA.png" height="15"> Blainville-Boisbriand Armada');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Cape Breton Screaming Eagles/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/CB.png" height="15"> Cape Breton Screaming Eagles');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Charlottetown Islanders/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/CHA.png" height="15"> Charlottetown Islanders');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Chicoutimi Sagueneens/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/CHI.png" height="15"> Chicoutimi Sagueneens');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Drummondville Voltigeurs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/DRU.png" height="15"> Drummondville Voltigeurs');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Gatineau Olympiques/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/GAT.png" height="15"> Gatineau Olympiques');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Halifax Mooseheads/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/HAL.png" height="15"> Halifax Mooseheads');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Moncton Wildcats/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/MON.png" height="15"> Moncton Wildcats');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Quebec Remparts/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/QUE.png" height="15"> Quebec Remparts');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Rimouski Oceanic/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/RIM.png" height="15"> Rimouski Oceanic');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Rouyn-Noranda Huskies/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/ROU.png" height="15"> Rouyn-Noranda Huskies');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Saint John Sea Dogs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/STJ.png" height="15"> Saint John Sea Dogs');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Shawinigan Cataractes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/SHA.png" height="15"> Shawinigan Cataractes');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Sherbrooke Phoenix/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/SHE.png" height="15"> Sherbrooke Phoenix');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Val d'Or Foreurs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/VAL.png" height="15"> Val dOr Foreurs');})();

// ###
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Victoriaville Tigres/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/QMJHL/VIC.png" height="15"> Victoriaville Tigres');})();

