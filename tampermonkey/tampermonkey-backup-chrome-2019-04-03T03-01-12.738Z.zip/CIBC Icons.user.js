// ==UserScript==
// @name         CIBC Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.cibc.ca/*
// @match        https://www.cibconline.cibc.com/*
// @match        https://www.cibc.com/*

// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/TIM/g,'<img src="https://media.glassdoor.com/sqll/15227/tim-hortons-squarelogo-1426776778485.png" height="15"> TIM');
})();


