// ==UserScript==
// @name         I Dunno
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==

// NHL
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Regular Season/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/stats/WINTER.png" height="15"> Regular Season');})();