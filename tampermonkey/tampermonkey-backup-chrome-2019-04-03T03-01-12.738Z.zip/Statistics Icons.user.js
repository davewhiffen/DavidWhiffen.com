// ==UserScript==
// @name         Statistics Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

// GP
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/GP/g,'<img src="http://www.goclutch.com/ryerson/images/stats/GP.png" height="20"> GP');})();

// PTS
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Pts/g,'<img src="http://www.goclutch.com/ryerson/images/stats/POINT2.png" height="20"> PTS');})();

// PIM
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/PIM/g,'<img src="http://www.goclutch.com/ryerson/images/stats/PIM3.png" height="20"> PIM');})();

// +/-
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/+/g,'<img src="http://www.goclutch.com/ryerson/images/stats/PLUS-MINUS2.png" height="20"> +');})();


// PTS
(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/TP/g,'<img src="http://www.goclutch.com/ryerson/images/stats/POINT2.png" height="20"> PTS');})();
