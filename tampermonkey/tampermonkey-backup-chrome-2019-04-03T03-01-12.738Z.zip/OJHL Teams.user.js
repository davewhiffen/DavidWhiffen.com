// ==UserScript==
// @name         OJHL Teams
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Aurora Tigers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/AUR.png" height="18"> Aurora Tigers');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Buffalo Jr. Sabres/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/BUF.png" height="18"> Buffalo Jr. Sabres');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Burlington Cougars/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/BUR.png" height="18"> Burlington Cougars');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Cobourg Cougars/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/COB.png" height="18"> Cobourg Cougars');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Georgetown Raiders/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/GEO.png" height="18"> Georgetown Raiders');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Kingston Voyageurs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/KIN.png" height="18"> Kingston Voyageurs');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Lindsay Muskies/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/LIN.png" height="18"> Lindsay Muskies');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Markham Royals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/MAR.png" height="18"> Markham Royals');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Milton Icehawks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/MIL.png" height="18"> Milton Icehawks');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Mississauga Chargers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/MIS.png" height="18"> Mississauga Chargers');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Newmarket Hurricanes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/NEW.png" height="18"> Newmarket Hurricanes');})();

// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/North York Rangers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/NOR.png" height="18"> North York Rangers');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Oakville Blades/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/OAK.png" height="18"> Oakville Blades');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Orangeville Flyers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/ORA.png" height="18"> Orangeville Flyers');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Pickering Panthers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/PIC.png" height="18"> Pickering Panthers');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/St. Michael's Buzzers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/STM.png" height="18"> St. Michaels Buzzers');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Stouffville Spirit/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/STO.png" height="18"> Stouffville Spirit');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toronto Jr. Canadiens/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/TOR.png" height="18"> Toronto Jr. Canadiens');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toronto Lakeshore Patriots/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/TORP.png" height="18"> Toronto Lakeshore Patriots');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Trenton Golden Hawks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/TRE.png" height="18"> Trenton Golden Hawks');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Wellington Dukes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/WEL.png" height="18"> Wellington Dukes');})();


// ##
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Whitby Fury/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OJHL/WHI.png" height="18"> Whitby Fury');})();



