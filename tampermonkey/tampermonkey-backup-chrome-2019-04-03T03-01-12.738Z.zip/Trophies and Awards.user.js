// ==UserScript==
// @name         Trophies and Awards
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==

// James Norris
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/James Norris Trophy/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/NORRIS.jpeg" height="18"> James Norris Trophy');})();

// Vezina
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Vezina Trophy/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/VEZINA.jpg" height="18"> Vezina Trophy');})();

// Jennings
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Jennings/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();

// Crozier
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();

// Jack Adams
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();

// King Clancy
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Crozier
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Maurice Richard
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Art Ross
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Lester Pearson
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Selke
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Messier
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Lindsay
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Lady Bing
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Hart
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Conn Smythe
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();

// Calder
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();


// Bill Masterson
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/trophy/###.jpeg" height="18"> ###');})();
