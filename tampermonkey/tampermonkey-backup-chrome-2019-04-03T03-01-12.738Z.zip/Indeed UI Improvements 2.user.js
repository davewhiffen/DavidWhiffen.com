// ==UserScript==
// @name         Indeed UI Improvements 2
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.indeed.ca/cmp/*
// @grant        none
// ==/UserScript==

// ==UserScript==
// @name         Indeed UI Improvements
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.indeed.ca/cmp/*
// @grant        none
// ==/UserScript==


// Toronto
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toronto, ON/g,'<img src="http://www.goclutch.com/indeed/UI/TOR.png" height="15"> Toronto, ON');})();


// New
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/new/g,'<img src="http://www.goclutch.com/indeed/UI/NEW.png" height="20"> new');})();


// $18
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/$18/g,'<img src="http://www.goclutch.com/indeed/UI/LOONIE.png" height="15"> $18');})();

// Krijoh Inc
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Krijoh Inc/g,'<img src="http://www.goclutch.com/indeed/UI/KRI.png" height="15"> Kriojoh Inc');})();


// Skilled Labour
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Skilled Labour/g,'<img src="http://www.goclutch.com/indeed/UI/SKILL.png" height="30"> Skilled Labour');})();

// Roofing
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/roofing/g,'<img src="http://www.goclutch.com/indeed/UI/ROOF.png" height="15"> roofing');})();


// Drywall
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/drywall/g,'<img src="http://www.goclutch.com/indeed/UI/DRY.png" height="15"> drywall');})();



// Tile
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/tile/g,'<img src="http://www.goclutch.com/indeed/UI/TILE.png" height="15"> tile');})();


// Forklift
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Forklift/g,'<img src="http://www.goclutch.com/indeed/UI/FORK.png" height="18"> Forklift');})();

// License
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Driver's/g,'<img src="http://www.goclutch.com/indeed/UI/LICENSE.png" height="15"> Drivers');})();

// License
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/driver's/g,'<img src="http://www.goclutch.com/indeed/UI/LICENSE.png" height="15"> Drivers');})();


// Carpenter
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Carpent/g,'<img src="http://www.goclutch.com/indeed/UI/CARP.png" height="25"> Carpent');})();


// Carpenter
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/carpent/g,'<img src="http://www.goclutch.com/indeed/UI/CARP.png" height="25"> carpent');})();


// Reno
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Renovat/g,'<img src="http://www.goclutch.com/indeed/UI/RENO.png" height="25"> Renovat');})();

// Reno
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/renovat/g,'<img src="http://www.goclutch.com/indeed/UI/RENO.png" height="25"> renovat');})();


// Required
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Required/g,'<img src="http://www.goclutch.com/indeed/UI/REQ.png" height="15"> Required');})();

// Required
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/required/g,'<img src="http://www.goclutch.com/indeed/UI/REQ.png" height="15"> required');})();


// Vehicle
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Vehicle/g,'<img src="http://www.goclutch.com/indeed/UI/CAR.png" height="15"> Vehicle');})();

// Vehicle
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/vehicle/g,'<img src="http://www.goclutch.com/indeed/UI/CAR.png" height="15"> vehicle');})();


// Tools
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/tools/g,'<img src="http://www.goclutch.com/indeed/UI/TOOLS.png" height="15"> tools');})();

// Diploma
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/diploma/g, '<img src="http://www.goclutch.com/indeed/UI/DIP.png" height="15"> diploma');})();

// Criminal Check
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/criminal background check/g, '<img src="http://www.goclutch.com/indeed/UI/CRI.png" height="15"> criminal background check');})();

// Labour
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Labour/g, '<img src="http://www.goclutch.com/indeed/UI/LAB.png" height="25"> Labour');})();

// Demo
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Demolition/g, '<img src="http://www.goclutch.com/indeed/UI/DEMO.png" height="25"> Demolition');})();

// Demo
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/demolition/g, '<img src="http://www.goclutch.com/indeed/UI/DEMO.png" height="25"> demolition');})();


// Framing
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Framing/g, '<img src="http://www.goclutch.com/indeed/UI/FRA.png" height="15"> Framing');})();

// Framing
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/framing/g, '<img src="http://www.goclutch.com/indeed/UI/FRA.png" height="15"> framing');})();


// Painter
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Painter/g, '<img src="http://www.goclutch.com/indeed/UI/PAI.png" height="25"> Painter');})();

// Painter
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/painter/g, '<img src="http://www.goclutch.com/indeed/UI/PAI.png" height="25"> painter');})();


// Paint
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/paint/g, '<img src="http://www.goclutch.com/indeed/UI/PAINT.png" height="15"> paint');})();


// XP
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/experience/g, '<img src="http://www.goclutch.com/indeed/UI/XP.png" height="15"> experience');})();

// XP
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Experience/g, '<img src="http://www.goclutch.com/indeed/UI/XP.png" height="15"> Experience');})();



// Master
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Master/g, '<img src="http://www.goclutch.com/indeed/UI/MAS.png" height="15"> Master');})();

// Stain
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/stain/g, '<img src="http://www.goclutch.com/indeed/UI/STA.png" height="15"> stain');})();

// Pay
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Pay/g, '<img src="http://www.goclutch.com/indeed/UI/LOONIE.png" height="15"> Pay');})();


// Plow Truck
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Plow Truck/g, '<img src="http://www.goclutch.com/indeed/UI/PLO.png" height="25"> Plow Truck');})();

// Golf
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Golf/g, '<img src="http://www.goclutch.com/indeed/UI/GOLF.png" height="25"> Golf');})();

// Maintainance
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Maintenance/g, '<img src="http://www.goclutch.com/indeed/UI/MAI.png" height="15"> Maintenance');})();

// Wood
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/wood/g, '<img src="http://www.goclutch.com/indeed/UI/WOO.png" height="15"> wood');})();

// Metal
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/metal/g, '<img src="http://www.goclutch.com/indeed/UI/MET.png" height="15"> metal');})();

// Stone
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/stone/g, '<img src="http://www.goclutch.com/indeed/UI/STO.png" height="15"> stone');})();


// Saw
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/saw/g, '<img src="http://www.goclutch.com/indeed/UI/SAW.png" height="15"> saw');})();


// Concrete
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Concrete/g, '<img src="http://www.goclutch.com/indeed/UI/CEM.png" height="15"> Concrete');})();

// Mason
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Mason/g, '<img src="http://www.goclutch.com/indeed/UI/MASON.png" height="15"> Mason');})();


// Bobcat
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Bobcat/g, '<img src="http://www.goclutch.com/indeed/UI/BOB.png" height="15"> Bobcat');})();

// Excavator
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/excavator/g, '<img src="http://www.goclutch.com/indeed/UI/EXC.png" height="15"> excavator');})();

// Excavator
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Excavator/g, '<img src="http://www.goclutch.com/indeed/UI/EXC.png" height="15"> Excavator');})();


// Lift
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/lift/g, '<img src="http://www.goclutch.com/indeed/UI/LIF.png" height="15"> lift');})();

// Weather
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/weather/g, '<img src="http://www.goclutch.com/indeed/UI/WEA.png" height="15"> weather');})();

// Hand Eye
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/hand-eye/g, '<img src="http://www.goclutch.com/indeed/UI/HAN.png" height="15"> hand-eye');})();

// Driver
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Driver/g, '<img src="http://www.goclutch.com/indeed/UI/DRI.png" height="15"> Driver');})();

// Work Ethic
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/work ethic/g, '<img src="http://www.goclutch.com/indeed/UI/WOR.png" height="15"> work ethic');})();


// CEMENT
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/cement/g, '<img src="http://www.goclutch.com/indeed/UI/CEM.png" height="15"> cement');})();


// CEMENT
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/concrete/g, '<img src="http://www.goclutch.com/indeed/UI/CEM.png" height="15"> concrete');})();


// STEEL
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/steel/g, '<img src="http://www.goclutch.com/indeed/UI/STE.png" height="15"> steel');})();

// PHYSICAL STRENGTH
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/physical strength/g, '<img src="http://www.goclutch.com/indeed/UI/STR.png" height="15"> physical strength');})();

// TEAM
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/team/g, '<img src="http://www.goclutch.com/indeed/UI/TEA.png" height="15"> team');})();

// Problem Solving
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/problem solv/g, '<img src="http://www.goclutch.com/indeed/UI/PRO.png" height="15"> problem solv');})();

// Foreman
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Foreman/g, '<img src="http://www.goclutch.com/indeed/UI/FOR.png" height="15"> Foreman');})();

// Foreman
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/foreman/g, '<img src="http://www.goclutch.com/indeed/UI/FOR.png" height="15"> foreman');})();


// Hammer
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/hammer/g, '<img src="http://www.goclutch.com/indeed/UI/HAM.png" height="15"> hammer');})();

// Level
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/level/g, '<img src="http://www.goclutch.com/indeed/UI/LEV.png" height="15"> level');})();

// Foreman
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/shovel/g, '<img src="http://www.goclutch.com/indeed/UI/SHO.png" height="15"> shovel');})();

// Drill
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/drill/g, '<img src="http://www.goclutch.com/indeed/UI/DRILL.png" height="15"> drill');})();

// Fence
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/fence/g, '<img src="http://www.goclutch.com/indeed/UI/FEN.png" height="15"> fence');})();

// Garden
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/garden/g, '<img src="http://www.goclutch.com/indeed/UI/GAR.png" height="15"> garden');})();

// Wheelbarrow
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/wheelbarrow/g, '<img src="http://www.goclutch.com/indeed/UI/WHE.png" height="15"> wheelbarrow');})();

// Lawn
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/lawn/g, '<img src="http://www.goclutch.com/indeed/UI/LAW.png" height="15"> lawn');})();

// Blueprint
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/blueprint/g, '<img src="http://www.goclutch.com/indeed/UI/BLU.png" height="15"> blueprint');})();

// Heavy Equipment
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/heavy equipment/g, '<img src="http://www.goclutch.com/indeed/UI/HEA.png" height="15"> heavy equipment');})();

// Jack Hammer
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/jack hammer/g, '<img src="http://www.goclutch.com/indeed/UI/JAC.png" height="15"> jack hammer');})();

// walkway
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/walkway/g, '<img src="http://www.goclutch.com/indeed/UI/WAL.png" height="15"> walkway');})();


// deck
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/deck/g, '<img src="http://www.goclutch.com/indeed/UI/DEC.png" height="15"> deck');})();

// measurement equipment
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/measurement equipment/g, '<img src="http://www.goclutch.com/indeed/UI/TAP.png" height="15"> measurement equipment');})();


















