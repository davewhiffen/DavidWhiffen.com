// ==UserScript==
// @name         NHL DRAFT SYMBOLS
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/ihdb/draft/*

// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Chicago/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CHI.png" height="15"> Chicago');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Anaheim/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/ANA.png" height="15"> Anaheim');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Arizona/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/ARI.png" height="20"> Arizona');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Boston/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/BOS.png" height="20"> Boston');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Buffalo/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/BUF.png" height="20"> Buffalo');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Calgary/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CAL.png" height="18"> Calgary');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Carolina/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CAR.png" height="18"> Carolina');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Columbus/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CBJ.png" height="18"> Columbus');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Colorado/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/COL.png" height="18"> Colorado');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Dallas/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/DAL.png" height="18"> Dallas');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Detroit/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/DET.png" height="18"> Detroit');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Edmonton/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/EDM.png" height="18"> Edmonton');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Florida/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/FLO.png" height="18"> Florida');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Los Angeles/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/LA.png" height="18"> Los Angeles');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Minnesota/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MIN.png" height="18"> Minnesota');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Toronto/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/TOR.png" height="18"> Toronto');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Montreal/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MON.png" height="18"> Montreal');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Montréal/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MON.png" height="18"> Montreal');
})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Nashville/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NAS.png" height="18"> Nashville');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/New Jersey/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NJ.png" height="18"> New Jersey');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/NY Islanders/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NYI.png" height="18"> NY Islanders');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/NY Rangers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NYR.png" height="18"> NY Rangers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Ottawa/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/OTT.png" height="18"> Ottawa');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Philadelphia/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/PHI.png" height="18"> Philadelphia');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Pittsburgh/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/PIT.png" height="18"> Pittsburgh');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/San Jose/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/SJ.png" height="18"> San Jose');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/St. Louis/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/STL.png" height="18"> St. Louis');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Tampa Bay/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/TB.png" height="18"> Tampa Bay');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Vancouver/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/VAN.png" height="18"> Vancouver');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Washington/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/WAS.png" height="18"> Washington');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Winnipeg/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/WIN.png" height="18"> Winnipeg');
})();



