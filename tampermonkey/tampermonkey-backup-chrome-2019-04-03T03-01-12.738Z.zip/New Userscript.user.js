// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
})();