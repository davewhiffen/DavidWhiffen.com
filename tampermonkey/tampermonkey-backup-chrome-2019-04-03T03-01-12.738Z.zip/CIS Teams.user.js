// ==UserScript==
// @name         CIS Teams
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==


//ONTARIO

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ryerson/g,'<img src="http://www.goclutch.com/ryerson/images/logos/RYE.png" height="20"> Ryerson');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/OUAA/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/OUA.png" height="20"> OUAA');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Carleton University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CAR.png" height="20"> Carleton Ravens');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Brock University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/BRO.png" height="20"> Brock Badgers');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Concordia University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CON2.png" height="20"> Concordia Stingers');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Guelph/g,'<img src="http://www.goclutch.com/ryerson/images/logos/GUE.png" height="20"> Guelph Gryphons');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Lakehead University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/LAK.png" height="20"> Lakehead Thunderwolves');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Laurentian University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/LTN.png" height="20">Laurentian Voyageurs');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/McGill University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/MCG.png" height="20"> McGill Redmen');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Nipissing University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/NIP.png" height="20">Nipissing Lakers');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Ottawa/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OTT.png" height="20"> Ottawa Gee Gees');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Queens University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/QUE.png" height="20"> Queens Gaels');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Royal Military College/g,'<img src="http://www.goclutch.com/ryerson/images/logos/RMC.png" height="20"> RMC Paladins');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Toronto/g,'<img src="http://www.goclutch.com/ryerson/images/logos/TOR.png" height="20"> Toronto Varsity Blues');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Ontario Institute of Technology/g,'<img src="http://www.goclutch.com/ryerson/images/logos/UOI.png" height="20"> UOIT Ridgebacks');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Quebec Trois Rivieres/g,'<img src="http://www.goclutch.com/ryerson/images/logos/UQT.png" height="20"> UQTR Patriotes');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Waterloo/g,'<img src="http://www.goclutch.com/ryerson/images/logos/wat.png" height="20"> Waterloo Warriors');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Windsor/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WIN.png" height="20"> Windsor Lancers');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/U. of Western Ontario/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WES.png" height="20"> Western Mustangs');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Wilfrid Laurier University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WLU.png" height="20"> Laurier Golden Hawks');})();


(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/York University/g,'<img src="http://www.goclutch.com/ryerson/images/logos/YOR.png" height="20"> York Lions');})();


//WEST

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UNB/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/UNB.png" height="20"> UNB');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Acadia/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/ACA.png" height="20"> Acadia');})();




