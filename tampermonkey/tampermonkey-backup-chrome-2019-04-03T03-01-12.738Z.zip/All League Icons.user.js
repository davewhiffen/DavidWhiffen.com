// ==UserScript==
// @name         All League Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==

// #NHL
(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/'NHL'/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/NHL.png" height="20"> NHL');
})();

//#AHL

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/AHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/AHL.png" height="20"> AHL');
})();

//#ECHL

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/ECHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/ECHL.png" height="20"> ECHL');
})();

//#SPHL

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/SPHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/SPHL.png" height="20"> SPHL');
})();

//#CIS

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/CIS/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/CIS.png" height="20"> CIS');
})();

//#NCAA

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/NCAA/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/NCAA.png" height="20"> NCAA');
})();

//#CHL



//#OJHL

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/OJHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/OJHL.png" height="20"> OJHL');
})();

//#OHL --------------



//#QMJHL

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/QMJHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/QMJHL.png" height="20"> QMJHL');
})();
