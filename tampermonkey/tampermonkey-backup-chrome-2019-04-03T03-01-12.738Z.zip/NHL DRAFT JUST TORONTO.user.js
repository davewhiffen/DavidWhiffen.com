// ==UserScript==
// @name         NHL DRAFT JUST TORONTO
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*

// @grant        none
// ==/UserScript==




(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Auston Matthews/g,'<img src="http://www.hockeydb.com/ihdb/photos/auston-matthews-2018-38.jpg" height="25"> Auston Matthews');
})();



