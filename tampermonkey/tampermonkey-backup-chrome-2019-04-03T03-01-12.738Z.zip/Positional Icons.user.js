// ==UserScript==
// @name         Positional Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Defense/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/DEFENSE.png" height="15"> Defense');
})();



(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Center/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/CENTER.png" height="15"> Center');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Left Wing/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/WING.png" height="15"> Left Wing');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/LW/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/WING.png" height="15"> Left Wing');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Right Wing/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/position/RWING.png" height="15"> Right Wing');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Goalie/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/GOALIE.png" height="15"> Goalie');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Forward/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/FORWARD.png" height="15"> Forward');
})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/RW/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/position/RWING.png" height="15"> Right Wing');
})();



