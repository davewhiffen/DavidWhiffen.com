// ==UserScript==
// @name         Goonies Modif
// @namespace    https://www.truenorthhockey.com/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.truenorthhockey.com/*
// @grant        none
// ==/UserScript==

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Goonies/g,'<img src="http://goclutch.com/goonies/images/logos/GOO2.png" height="15"> Goonies');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mutiny/g,'<img src="http://goclutch.com/mutiny/images/logos/mutiny2.png" height="15"> Mutiny');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Tide/g,'<img src="http://goclutch.com/goonies/images/logos/TID.png" height="15"> Tide');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto Ice Dogs/g,'<img src="http://goclutch.com/ryerson/images/logos/CHL/OHL/NIA.png" height="15"> Toronto Ice Dogs');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ice Age/g,'<img src="http://goclutch.com/ryerson/images/logos/NHL/EDM.png" height="15"> Ice Age');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto Marauders/g,'<img src="https://www.truenorthhockey.com/TeamLogos/TorontoMarauders1.png" height="15"> Toronto Marauders');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Tanks/g,'<img src="http://goclutch.com/ryerson/images/logos/CHL/OHL/NB.png" height="15"> Tanks');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Icemen/g,'<img src="http://goclutch.com/ryerson/images/logos/ECHL/EVA.PNG" height="15"> Icemen');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mighty Pirates/g,'<img src="https://www.truenorthhockey.com/TeamLogos/MightyPirates1.png" height="15"> Mighty Pirates');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Grrrowl/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Grrrowl1.png" height="15"> Grrrowl');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mongolian Horde/g,'<img src="https://www.truenorthhockey.com/TeamLogos/MongolianHorde1.png" height="15"> Mongolian Horde');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Dirty Pucks/g,'<img src="https://www.truenorthhockey.com/TeamLogos/DirtyPucks1.png" height="15"> Dirty Pucks');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto Rage/g,'<img src="https://www.truenorthhockey.com/TeamLogos/TorontoRage1.png" height="15"> Toronto Rage');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Brewstars/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Brewstars1.png" height="15"> Brewstars');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Cyclones/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Cyclones1.png" height="15"> Cyclones');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Drunken Monkeys/g,'<img src="https://www.truenorthhockey.com/TeamLogos/DrunkenMonkeys1.png" height="15"> Drunken Monkeys');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto Benchwarmers/g,'<img src="https://www.truenorthhockey.com/TeamLogos/TorontoBenchwarmers1.png" height="15"> Toronto Benchwarmers');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ricoh Coliseum/g,'<img src="https://upload.wikimedia.org/wikipedia/en/1/1c/Ricoh.png" height="15"> Ricoh Coliseum');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/MasterCard/g,'<img src="https://lakeshorearena.ca/wp-content/themes/hockey-arena/images/MCC-logo-cropped.jpg" height="15"> Mastercard');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Exposed/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/3/32/Montreal_Expos_Logo.svg/1024px-Montreal_Expos_Logo.svg.png" height="15"> Exposed');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Dave Whiffen/g,'<img src="https://pbs.twimg.com/profile_images/747522973519740929/RdT8mJFH.jpg" height="15"><strong> Dave Whiffen</strong>');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Chris Blouin/g,'<img src="http://www.goclutch.com/goonies/images/players/40%20Blouin.png" height="15"> Chris Blouin');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Greg Rosen/g,'<img src="http://www.goclutch.com/goonies/images/players/93%20Rosen.png" height="15"> Greg Rosen');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Sam Roston/g,'<img src="https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/3/000/1d6/12d/0b251a0.jpg" height="15"> Sam Roston');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Paul Choi/g,'<img src="https://pbs.twimg.com/profile_images/507735248818302976/4Uvi8SV_.jpeg" height="15"> Paul Choi');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Scott Alexander/g,'<img src="https://pbs.twimg.com/profile_images/788045248882769925/gp29RN2n.jpg" height="15"> Scott Alexander');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mob Barley/g,'<img src="https://www.truenorthhockey.com/TeamLogos/MobBarley1.png" height="15"> Mob Barley');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/###/g,'<img src="###" height="15"> ###');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Vultures/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Vultures1.png" height="15"> Vultures');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Hitmen/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Hitmen1.png" height="15"> Hitmen');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/TO Rangers/g,'<img src="https://www.truenorthhockey.com/TeamLogos/TORangers1.png" height="15"> TO Rangers');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Panthers/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Panthers1.png" height="15"> Panthers');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mighty Thundercats/g,'<img src="https://www.truenorthhockey.com/TeamLogos/MightyThundercats1.png" height="15"> Mighty Thundercats');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Crazy Canucks/g,'<img src="https://www.truenorthhockey.com/TeamLogos/CrazyCanucks1.png" height="15"> Crazy Canucks');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Gourds/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Gourds1.png" height="15"> Gourds');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/California Sandwiches/g,'<img src="https://www.truenorthhockey.com/TeamLogos/CaliforniaSandwiches1.png" height="15"> California Sandwiches');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/HVAC Wolfpack/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/3/3f/Hartford-Wolf-Pack-Logo.svg/1076px-Hartford-Wolf-Pack-Logo.svg.png" height="15"> HVAC Wolfpack');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Beauties and the Beast/g,'<img src="https://www.truenorthhockey.com/TeamLogos/Beauties1.png" height="15"> Beauties and the Beast');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Brew Balls/g,'<img src="https://cdn3.vox-cdn.com/uploads/blog/sbnu_logo/13/brewcrewball.com.full.48867.52124.png" height="15"> Brew Balls');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/North Stars/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/5/56/Minnesota_North_Stars_Logo_2.svg/801px-Minnesota_North_Stars_Logo_2.svg.png" height="15"> North Stars');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Bloodlust/g,'<img src="https://www.nativeskatestore.co.uk/images/spitfire-monster-mash-bloodlust-skateboard-sticker-p13583-30267_medium.jpg" height="15"> Bloodlust');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Power Raiders/g,'<img src="http://vignette4.wikia.nocookie.net/logopedia/images/7/71/MMPR_Era_Logo.png/revision/latest?cb=20140212040130" height="15"> Power Raiders');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Phantoms/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/a/a2/Philadelphia_Phantoms.svg/1094px-Philadelphia_Phantoms.svg.png" height="15"> Phantoms');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/B-Beavers/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/c/c6/OSU_beavers.svg/1280px-OSU_beavers.svg.png" height="15"> B-Beavers');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Red Wingers/g,'<img src="http://i.imgur.com/eHNed3H.png" height="15"> Red Wingers');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Catfish Tapas/g,'<img src="http://content.sportslogos.net/logos/45/2741/full/e7jt61ggwvyg1o4g20dekmp3t.gif" height="15"> Catfish Tapas');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Smell the Glove/g,'<img src="https://ih0.redbubble.net/image.119827202.9063/sticker,420x460-pad,420x460,f8f8f8.u6.jpg" height="15"> Smell the Glove');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Aeros/g,'<img src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b7/Houston_Aeros.svg/1148px-Houston_Aeros.svg.png" height="15"> Aeros');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Highest Puck/g,'<img src="http://piratehockey.ca/Images/Opponents/logo-97.gif" height="15"> Highest Puck');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/50's/g,'<img src="http://vignette4.wikia.nocookie.net/bioshock/images/b/bb/120px-Old_Man_Winter_Icon.png/revision/latest?cb=20131114182312&path-prefix=de" height="15"> 50s');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Dan Pringle/g,'<img src="https://media.licdn.com/mpr/mpr/shrinknp_200_200/AAEAAQAAAAAAAAZJAAAAJDdiMmZkMTY5LWE4MDUtNDIxNC04ZDQyLTcwNzcxYTBlYWEwZg.jpg" height="15"> Dan Pringle');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Yuriy Dyachenko/g,'<img src="https://avatars1.githubusercontent.com/u/2188752?v=3&s=400" height="15"> Yuriy Dyachenko');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Kenny Zhang/g,'<img src="http://www.goclutch.com/goonies/images/players/14%20Zhang.png" height="15"> Kenny Zhang');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Quang Tran/g,'<img src="http://www.goclutch.com/goonies/images/players/87%20Tran.png" height="15"> Quang Tran');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ricky Ma/g,'<img src="http://www.goclutch.com/goonies/images/players/82%20Ma.png" height="15"> Ricky Ma');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Jeffrey Major/g,'<img src="http://www.goclutch.com/goonies/images/players/24%20Major.png" height="15"> Jeffrey Major');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mike Harrinandon/g,'<img src="http://www.goclutch.com/goonies/images/players/71%20Harrindon.png" height="15"> Mike Harrinandon');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mitch Finn/g,'<img src="http://www.goclutch.com/goonies/images/players/15%20Finn.png" height="15"> Mitch Finn');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Arthur Blouin/g,'<img src="http://www.goclutch.com/goonies/images/players/97%20Blouin.png" height="15"> Arthur Blouin');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Zach Crosby/g,'<img src="http://www.goclutch.com/goonies/images/players/66%20Crosby.png" height="15"> Zach Crosby');})();






