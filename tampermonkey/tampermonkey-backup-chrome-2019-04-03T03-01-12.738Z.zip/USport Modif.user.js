// ==UserScript==
// @name         USport Modif
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        en.usports.ca/*
// @grant        none
// ==/UserScript==

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ryerson/g,'<img src="http://www.goclutch.com/ryerson/images/logos/RYE.png" height="20"> Ryerson');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ryerson"/g,'');})();



(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Carleton/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CAR.png" height="20"> Carleton');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Carleton"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Brock/g,'<img src="http://www.goclutch.com/ryerson/images/logos/BRO.png" height="20"> Brock');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Brock"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Concordia/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CON2.png" height="20"> Concordia');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Concordia"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Guelph/g,'<img src="http://www.goclutch.com/ryerson/images/logos/GUE.png" height="20"> Guelph');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Guelph"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Lakehead/g,'<img src="http://www.goclutch.com/ryerson/images/logos/LAK.png" height="20"> Lakehead');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Lakehead"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Laurentian/g,'<img src="http://www.goclutch.com/ryerson/images/logos/LTN.png" height="20">Laurentian');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Laurentian"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/McGill/g,'<img src="http://www.goclutch.com/ryerson/images/logos/MCG.png" height="20"> McGill');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/McGill"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Nipissing/g,'<img src="http://www.goclutch.com/ryerson/images/logos/NIP.png" height="20">Nipissing');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Nipissing"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Ottawa/g,'<img src="http://www.goclutch.com/ryerson/images/logos/OTT.png" height="20"> Ottawa');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Ottawa"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Queen's/g,'<img src="http://www.goclutch.com/ryerson/images/logos/QUE.png" height="20"> Queens');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Queens"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/RMC/g,'<img src="http://www.goclutch.com/ryerson/images/logos/RMC.png" height="20"> RMC');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/RMC"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toronto/g,'<img src="http://www.goclutch.com/ryerson/images/logos/TOR.png" height="20"> Toronto');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Toronto"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/UOIT/g,'<img src="http://www.goclutch.com/ryerson/images/logos/UOI.png" height="20"> UOIT');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UOIT"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/UQTR/g,'<img src="http://www.goclutch.com/ryerson/images/logos/UQT.png" height="20"> UQTR');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UQTR"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Waterloo/g,'<img src="http://www.goclutch.com/ryerson/images/logos/wat.png" height="20"> Waterloo');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Waterloo"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Windsor/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WIN.png" height="20"> Windsor');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Windsor"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Western/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WES.png" height="20"> Western');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Western"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Laurier/g,'<img src="http://www.goclutch.com/ryerson/images/logos/WLU.png" height="20"> Laurier');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Laurier"/g,'');})();

(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/York/g,'<img src="http://www.goclutch.com/ryerson/images/logos/YOR.png" height="20"> York');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/York"/g,'');})();

//AUS

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UNB/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/UNB.png" height="20"> UNB');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UNB"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Acadia/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/ACA.png" height="20"> Acadia');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Acadia"/g,'');})();



(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Saint Mary's/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/SMU.png" height="20"> Saint Marys');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Saint Marys"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/StFX/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/SFX.png" height="20"> StFX');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/StFX"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UPEI/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/UPEI.png" height="20"> UPEI');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UPEI"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Moncton/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/MCT.png" height="20"> Moncton');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Moncton"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Dalhousie/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AUS/DAL.png" height="20"> Dalhousie');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Dalhousie"/g,'');})();

//WEST

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Saskatchewan/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/SASK.png" height="20"> Saskatchewan');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Saskatchewan"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mount Royal/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/MRU.png" height="20"> Mount Royal');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Mount Royal"/g,'');})();


(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Alberta/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/ALB.png" height="20"> Alberta');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Alberta"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Calgary/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/CAL.png" height="20"> Calgary');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Calgary"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Lethbridge/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/LET.png" height="20"> Lethbridge');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Lethbridge"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Regina/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/REG.png" height="20"> Regina');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Regina"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Manitoba/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/MAN.png" height="20"> Manitoba');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Manitoba"/g,'');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UBC/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CANW/UBC.png" height="20"> UBC');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/UBC"/g,'');})();



(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/OUA/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/OUA.png" height="35"> ONTARIO');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/CANADA WEST/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/CANW.png" height="35"> WEST');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/2017 U SPORTS Cavendish Farms University Cup/g,'<img src="http://www.goclutch.com/ryerson/images/playoffs/UCUP.png" height="30"> 2017 U SPORTS Cavendish Farms University Cup');})();

(function() {'use strict';document.body.innerHTML = document.body.innerHTML.replace(/Sportsnet 360/g,'<img src="http://www.fibreop.ca/binaries/small/content/gallery/common_en/tv/channel-logos/sportsnet_360.png" height="35"> Sportsnet 360');})();


