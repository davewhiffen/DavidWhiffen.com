// ==UserScript==
// @name         Country of Origin
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==

// Canada
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Canada/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/CAN.png" height="15"> Canada');})();

// USA
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/USA/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/USA.png" height="15"> USA');})();

// Sweden
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Sweden/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/SWE.png" height="15"> Sweden');})();

// Russia
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Russia/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/RUS.png" height="15"> Russia');})();

// Slovakia
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Slovakia/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/SLO.png" height="15"> Slovakia');})();


// Czech Repub
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Czech Rep./g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/CZE.png" height="15"> Czech Rep.');})();


// Finland
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Finland/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/FIN.png" height="15"> Finland');})();

// Germany
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Germany/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/country/GER.png" height="15"> Germany');})();



