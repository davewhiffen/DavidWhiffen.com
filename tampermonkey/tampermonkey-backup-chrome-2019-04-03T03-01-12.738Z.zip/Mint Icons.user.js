// ==UserScript==
// @name         Mint Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mint.intuit.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Tim Horton/g,'<img src="http://www.goclutch.com/ryerson/images/logos/rye.png" height="15"> Tim Horton');
})();