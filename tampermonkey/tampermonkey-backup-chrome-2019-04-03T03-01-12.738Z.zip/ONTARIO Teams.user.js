// ==UserScript==
// @name         ONTARIO Teams
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Belleville Bulls/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/past/BEL.png" height="18"> Belville Bulls');
})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Barrie Colts/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/BAR.png" height="18"> Barrie Colts');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Erie Otters/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/ERI.png" height="18"> Erie Otters');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Flint Firebirds/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/FLI.png" height="18"> Flint Firebirds');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Guelph Storm/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/GUE.png" height="18"> Guelph Storm');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Hamilton Bulldogs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/HAM.png" height="18"> Hamilton Bulldogs');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Kingston Frontenacs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/KIN2.png" height="18"> Kingston Frontenacs');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Kitchener Rangers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/KIT.png" height="18"> Kitchener Rangers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/London Knights/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/LON.png" height="18"> London Knights');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Mississauga Steelheads/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/MIS.jpg" height="18"> Mississauga Steelheads');
})();

// North Bay Battalion
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/North Bay Battalion/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/NB.png" height="18"> North Bay Battalion');})();

// Brampton Battalion
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Brampton Battalion/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/NB.png" height="18"> Brampton Battalion');})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Niagara IceDogs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/NIA.png" height="18"> Niagara IceDogs');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Owen Sound Attack/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/OS.png" height="18"> Owen Sound Attack');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Oshawa Generals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/OSH.png" height="18"> Oshawa Generals');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Ottawa 67's/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/OTT.png" height="18"> Ottawa 67s');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Peterborough Petes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/PB.png" height="18"> Peterborough Petes');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Saginaw Spirit/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/SAG.png" height="18"> Saginaw Spirit');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Sarnia Sting/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/SAR.png" height="18"> Sarnia Sting');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Soo Greyhounds/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/SOO.png" height="18"> Soo Greyhounds');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Sudbury Wolves/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/SUD.png" height="18"> Sudbury Wolves');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Windsor Spitfires/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/WIN.png" height="18"> Windsor Spitfires');
})();


// DEFUNCT TEAMS

document.body.innerHTML = document.body.innerHTML.replace(/Sault Ste. Marie Greyhounds/g,'<img src="http://www.goclutch.com/ryerson/images/logos/CHL/ONTARIO/SOO.png" height="18"> Sault Ste. Marie Greyhounds');

