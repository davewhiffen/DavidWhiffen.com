// ==UserScript==
// @name         Home Province
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @grant        none
// ==/UserScript==

// British Columbia
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, BC/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/BC.png" height="15"> BC');})();

// Alberta
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, ALTA/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/ALTA.png" height="15"> ALTA');})();

// Saskatchewan
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, SASK/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/SASK.png" height="15"> SASK');})();

// Manitoba
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, MAN/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/MAN.png" height="15"> MAN');})();

// Ontario
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, ONT/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/ONT.png" height="15"> ONT');})();

// Quebec
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, PQ/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/QUE.png" height="15"> QUE');})();

// New Brunswick
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, NB/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/NB.png" height="15"> NB');})();

// Nova Scotia
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, NS/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/NS.png" height="15"> NS');})();

// PEI
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, PEI/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/PEI.png" height="15"> PEI');})();

// Newfoundland
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/, NF/g,', <img src="http://www.goclutch.com/ryerson/images/hockeydb/province/NF.png" height="15"> NF');})();



