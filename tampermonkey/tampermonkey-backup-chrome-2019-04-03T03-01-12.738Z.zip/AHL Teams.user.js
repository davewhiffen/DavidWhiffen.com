// ==UserScript==
// @name         AHL Teams
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Albany Devils/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/ALB.png" height="18"> Albany Devils');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Bakersfield Condors/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/BAK.png" height="18"> Bakersfield Condors');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Binghamton Senators/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/BIN.png" height="18"> Binghamton Senators');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Bridgeport Sound Tigers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/BRI.png" height="18"> Bridgeport Sound Tigers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Charlotte Checkers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/CHA.png" height="18"> Charlotte Checkers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Chicago Wolves/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/CHI.png" height="18"> Chicago Wolves');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Grand Rapids Griffins/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/GR.png" height="18"> Grand Rapids Griffins');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Hartford Wolf Pack/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/HAR.png" height="18"> Hartford Wolf Pack');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Hershey Bears/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/HER.jpg" height="18"> Hershey Bears');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Iowa Wild/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/IOW.png" height="18"> Iowa Wild');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Cleveland River Monsters/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/LE.png" height="18"> Cleveland River Monsters');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Leigh Valley Phantoms/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/LV.png" height="18"> Leigh Valley Phantoms');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Manitoba Moose/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/MAN.png" height="18"> Manitoba Moose');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Milwaukee Admirals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/MIL.png" height="18"> Milwaukee Admirals');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Ontario Reign/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/ONT.png" height="18"> Ontario Reign');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Portland Pirates/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/POR.png" height="18"> Portland Pirates');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Providence Bruins/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/PRO.png" height="18"> Providence Bruins');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Rockford Ice Hogs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/RF.png" height="18"> Rockford Ice Hogs');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/San Antonio Rampage/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/SA.png" height="18"> San Antonio Rampage');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/San Diego Gulls/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/SD.png" height="18"> San Diego Gulls');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/San Jose Barracuda/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/SJ.png" height="18"> San Jose Barracuda');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Springfield Thunderbirds/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/SPR.png" height="18"> Springfield Thunderbirds');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/St. John's Ice Caps/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/STJ.png" height="18"> St. Johns Ice Caps');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Stockton Heat/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/STO.png" height="18"> Stockton Heat');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Syracuse Crunch/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/SYR.png" height="18"> Syracuse Crunch');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Texas Stars/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/TEX.png" height="18"> Texas Stars');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Toronto Marlies/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/TOR.png" height="18"> Toronto Marlies');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Utica Comets/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/UTI.png" height="18"> Utica Comets');
})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Wilkes-Barre/g,'<img src="http://www.goclutch.com/ryerson/images/logos/AHL/WBS.png" height="18"> Wilkes-Barre/');
})();


