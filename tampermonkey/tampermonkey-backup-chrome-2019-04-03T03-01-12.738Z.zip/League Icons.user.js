// ==UserScript==
// @name         League Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

// NHL
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/NHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/NHL.png" height="20"> NHL');})();

// AHL
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/AHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/AHL.png" height="20"> AHL');})();

// OHL
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/OHL/g,'<img src="http://www.goclutch.com/ryerson/images/logos/league/OHL.png" height="20"> OHL');})();



