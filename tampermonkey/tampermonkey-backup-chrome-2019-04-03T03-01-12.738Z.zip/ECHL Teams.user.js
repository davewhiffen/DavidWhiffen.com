// ==UserScript==
// @name         ECHL Teams
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

// Adirondack Thunder
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Adirondack Thunder/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ADI.png" height="18"> Adirondack Thunder');})();

// Alaska Aces
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Alaska Aces/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ALA.png" height="18"> Alaska Aces');})();

// Allen Americans
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Allen Americans/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ALL.png" height="18"> Allen Americans');})();

// Atlanta Gladiators
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Atlanta Gladiators/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ATL.png" height="18"> Atlanta Gladiators');})();


// Brampton Beast
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Brampton Beast/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/BRA.png" height="18"> Brampton Beast');})();

// Cincinnati Cyclones
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Cincinnati Cyclones/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/CIN.png" height="18"> Cincinnati Cyclones');})();

// Colorado Eagles
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Colorado Eagles/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/COL.png" height="18"> Colorado Eagles');})();

// Elmira Jackals
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Elmira Jackals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ELM.png" height="18"> Elmira Jackals');})();

// Evansville Icemen
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Evansville Icemen/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/EVA.png" height="18"> Evansville Icemen');})();

// Florida Everblades
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Florida Everblades/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/FLO.png" height="18"> Florida Everblades');})();

// Fort Wayne Komets
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Fort Wayne Komets/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/FOR.png" height="18"> Fort Wayne Komets');})();

// Greenville Swamp Rabbits
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Greenville Swamp Rabbits/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/GRE.png" height="18"> Greenville Swamp Rabbits');})();

// Idaho Steelheads
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Idaho Steelheads/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/IDA.png" height="18"> Idaho Steelheads');})();

// Indy Fuel
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Indy Fuel/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/IND.png" height="18"> Indy Fuel');})();

// Kalamazoo Wings
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Kalamazoo Wings/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/KAL.png" height="18"> Kalamazoo Wings');})();

// Manchester Monarchs
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Manchester Monarchs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/MAN.png" height="18"> Manchester Monarchs');})();

// Missouri Mavericks
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Missouri Mavericks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/MIS.png" height="18"> Missouri Mavericks');})();

// Norfolk Admirals
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Norfolk Admirals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/NOR.png" height="18"> Norfolk Admirals');})();

// Orlando Solar Bears
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Orlando Solar Bears/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/ORL.png" height="18"> Orlando Solar Bears');})();

// Quad City Mallads
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Quad City Mallards/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/QUA.png" height="18"> Quad City Mallads');})();

// Rapid City Rush
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Rapid City Rush/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/RAP.png" height="18"> Rapid City Rush');})();

// Reading Royals
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Reading Royals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/REA.png" height="18"> Reading Royals');})();

// South Carolina Stingrays
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/South Carolina Stingrays/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/SC.png" height="18"> South Carolina Stingrays');})();

// Toledo Walleye
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Toledo Walleye/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/TOL.png" height="18"> Toledo Walleye');})();

// Tulsa Oilers
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Tulsa Oilers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/TUL.png" height="18"> Tulsa Oilers');})();

// Utah Grizzlies
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Utah Grizzlies/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/UTA.png" height="18"> Utah Grizzlies');})();

// Wheeling Nailers
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Wheeling Nailers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/WHE.png" height="18"> Wheeling Nailers');})();

// Wichita Thunder
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Wichita Thunder/g,'<img src="http://www.goclutch.com/ryerson/images/logos/ECHL/WIC.png" height="18"> Wichita Thunder');})();







