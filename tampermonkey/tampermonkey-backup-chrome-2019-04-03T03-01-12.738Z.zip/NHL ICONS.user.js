// ==UserScript==
// @name         NHL ICONS
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @match        http://rutracker.org/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Chicago Blackhawks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CHI.png" height="15"> Chicago Blackhawks');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Anaheim Ducks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/ANA.png" height="15"> Anaheim Ducks');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Arizona Coyotes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/ARI.png" height="20"> Arizona Coyotes');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Boston Bruins/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/BOS.png" height="20"> Boston Bruins');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Buffalo Sabres/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/BUF.png" height="20"> Buffalo Sabres');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Calgary Flames/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CAL.png" height="18"> Calgary Flames');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Carolina Hurricanes/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CAR.png" height="18"> Carolina Hurricanes');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Columbus Blue Jackets/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/CBJ.png" height="18"> Columbus Blue Jackets');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Colorado Avalanche/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/COL.png" height="18"> Colorado Avalanche');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Dallas Stars/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/DAL.png" height="18"> Dallas Stars');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Detroit Red Wings/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/DET.png" height="18"> Detroit Red Wings');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Edmonton Oilers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/EDM.png" height="18"> Edmonton Oilers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Florida Panthers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/FLO.png" height="18"> Florida Panthers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Los Angeles Kings/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/LA.png" height="18"> Los Angeles Kings');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Minnesota Wild/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MIN.png" height="18"> Minnesota Wild');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Toronto Maple Leafs/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/TOR.png" height="18"> Toronto Maple Leafs');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Montreal Canadiens/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MON.png" height="18"> Montreal Canadiens');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Montréal Canadiens/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/MON.png" height="18"> Montreal Canadiens');
})();


(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Nashville Predators/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NAS.png" height="18"> Nashville Predators');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/New Jersey Devils/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NJ.png" height="18"> New Jersey Devils');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/New York Islanders/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NYI.png" height="18"> New York Islanders');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/New York Rangers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/NYR.png" height="18"> New York Rangers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Ottawa Senators/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/OTT.png" height="18"> Ottawa Senators');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Philadelphia Flyers/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/PHI.png" height="18"> Philadelphia Flyers');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Pittsburgh Penguins/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/PIT.png" height="18"> Pittsburgh Penguins');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/San Jose Sharks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/SJ.png" height="18"> San Jose Sharks');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/St. Louis Blues/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/STL.png" height="18"> St. Louis Blues');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Tampa Bay Lightning/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/TB.png" height="18"> Tampa Bay Lightning');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Vancouver Canucks/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/VAN.png" height="18"> Vancouver Canucks');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Washington Capitals/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/WAS.png" height="18"> Washington Capitals');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Winnipeg Jets/g,'<img src="http://www.goclutch.com/ryerson/images/logos/EP%20DUPE/NATIONAL/WIn.png" height="18"> Winnipeg Jets');
})();



