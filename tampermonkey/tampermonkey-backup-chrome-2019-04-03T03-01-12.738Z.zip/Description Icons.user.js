// ==UserScript==
// @name         Description Icons
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.hockeydb.com/*
// @match        http://www.eliteprospects.com/*
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==


// Shoots L
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/shoots L/g,'Shoots L <img src="http://www.goclutch.com/ryerson/images/icons/position/LEFT.png" height="15">');})();

// Shoots R
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/shoots R/g,'Shoots R <img src="http://www.goclutch.com/ryerson/images/hockeydb/position/RIGHT.png" height="15">');})();




(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Born/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/BORN.png" height="15"> Born');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Date of birth/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/BORN.png" height="15"> Born');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/BIRTHYEAR/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/BORN.png" height="15"> BIRTHYEAR');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Height/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/HEIGHT.png" height="15"> Height');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Weight/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/WEIGHT.png" height="15"> Weight');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/HEIGHT/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/HEIGHT.png" height="15"> Height');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/WEIGHT/g,'<img src="http://www.goclutch.com/ryerson/images/icons/position/WEIGHT.png" height="15"> Weight');
})();

// Drafted
(function() {'use strict'; document.body.innerHTML = document.body.innerHTML.replace(/Drafted/g,'<img src="http://www.goclutch.com/ryerson/images/hockeydb/position/DRAFTED.png" height="18"> Drafted');})();



