// ==UserScript==
// @name         Catchvideo.net helper
// @namespace    https://catchvideo.net/
// @version      0.13
// @description  This userscript help Catchvideo.net in fetching download links
// @copyright    2018+, Catchvideo.net
// @author       Catchvideo.net
// @icon         https://catchvideo.net/static/img/cv128.png
// @icon64       https://catchvideo.net/static/img/cv64.png
// @homepage     https://catchvideo.net/software
// @updateURL    https://catchvideo.net/static/js/Catchvideo.net-helper.meta.js
// @downloadURL  https://catchvideo.net/static/js/Catchvideo.net-helper.user.js
// @match        https://catchvideo.net/*
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// ==/UserScript==


function catch_ap(obj){
    //Build object for GM_xmlhttpRequest()
    var gm_xhr = {};
    gm_xhr.url = obj.url;
    
    (obj.method!==undefined) ? gm_xhr.method=obj.method : gm_xhr.method="GET";
    if(obj.locationonly=="yes") gm_xhr.method="HEAD";
    
    gm_xhr.headers = {};
    if(obj.ua!==undefined) gm_xhr.headers["User-Agent"]=obj.ua;
    if(obj.postdata!==undefined) gm_xhr.headers["Content-Type"]="application/x-www-form-urlencoded";
    if(obj.referer!==undefined) gm_xhr.headers["Referer"]=obj.referer;
    if(obj.cookie!==undefined) gm_xhr.headers["Cookie"]=obj.cookie;
    
    if(obj.postdata!==undefined) gm_xhr.data = obj.postdata;
    
    if(obj.locationonly=="yes"){
        gm_xhr.onload = function(response) {
            var loc="";
            try{
                loc = response.finalUrl;
                if(loc==="") loc=response.responseHeaders.match(/Location: ([^\r\n]+)/i)[1];
            }catch(ex){
                
            }
            document.getElementById("catchvideo_data").innerHTML=loc;
        };
    }else{
        gm_xhr.onload = function(response) {
            document.getElementById("catchvideo_data").innerHTML=response.responseText;
        };
    }
    GM_xmlhttpRequest(gm_xhr);
}


var el = document.createElement('script');
el.innerHTML='var catchvideo_ext_loaded = true;';
var head = document.head || document.getElementsByTagName('head')[0];
head.insertBefore(el, head.lastChild);

setInterval(function(){
    try{
        if(document.getElementById("catchvideo_obj").innerHTML.toString()!="~none"){
            var catchvideo_obj = document.getElementById("catchvideo_obj").innerHTML;
            catchvideo_obj = catchvideo_obj.replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&");

            //Parse the JSON parameters
            //Execute the request
            catch_ap(JSON.parse(catchvideo_obj));

            //Empty the textarea to make it re-useable
            document.getElementById("catchvideo_obj").innerHTML="~none";
        }
    }catch(ex){

    }
},20);