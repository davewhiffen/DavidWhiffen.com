// ==UserScript==
// @name         Hockey Operations
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.eliteprospects.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Head Coach/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/HED.png" height="15"> Head Coach');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/HC/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/HED.png" height="15"> HC');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/General Manager/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/GEN.png" height="15"> General Manager');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/GM/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/GEN.png" height="15"> GM');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/President/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/PRZ3.png" height="15"> President');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/VP. of Hockey Operations/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/PRZ3.png" height="15"> VP. of Hockey Operations');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/VP of Hockey Operations/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/PRZ3.png" height="15"> VP of Hockey Operations');
})();

(function() {
    'use strict';
    document.body.innerHTML = document.body.innerHTML.replace(/Franchise Owner/g,'<img src="http://goclutch.com/ryerson/images/icons/hockey%20ops/OWNR.png" height="15"> Franchise Owner');
})();

